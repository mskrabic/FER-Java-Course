package hr.fer.zemris.java.gui.calc;

import java.awt.Color;
import java.awt.Container;
import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.List;
import java.util.Stack;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

import hr.fer.zemris.java.gui.calc.model.CalcModel;
import hr.fer.zemris.java.gui.calc.model.CalculatorInputException;
import hr.fer.zemris.java.gui.calc.model.impl.CalcModelImpl;
import hr.fer.zemris.java.gui.layouts.CalcLayout;

/**
 * Razred predstavlja implementaciju jednostavnog kalkulatora. Unos se vrši
 * klikom miša na gumbe, a podržane su neke osnovne funkcije i njihovi inverzi.
 * 
 * @author mskrabic
 *
 */
public class Calculator extends JFrame {

	private static final long serialVersionUID = 1L;

	/**
	 * Model kalkulatora.
	 */
	private CalcModel model = new CalcModelImpl();
	/**
	 * Lista koja pamti gumbe koji provode operacije koje imaju inverz.
	 */
	private List<CalcButton> invertibleOperations = new ArrayList<CalcButton>();

	/**
	 * Stog kalkulatora.
	 */
	private Stack<Double> stack = new Stack<>();

	/**
	 * Pretpostavljeni konstruktor koji inicijalizira kalkulator.
	 */
	public Calculator() {
		super();
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setTitle("Java Calculator v1.0");
		setLocation(20, 20);
		setSize(500, 200);
		initGUI();
	}

	/**
	 * Pomoćna metoda za inicijalizaciju grafičkih komponenti kalkulatora.
	 */
	private void initGUI() {
		Container cp = getContentPane();
		cp.setLayout(new CalcLayout(3));
		
		JLabel screen = new JLabel(model.toString());
		model.addCalcValueListener(e -> screen.setText(model.toString()));
		screen.setBackground(Color.YELLOW);
		screen.setOpaque(true);
		screen.setHorizontalAlignment(SwingConstants.RIGHT);
		screen.setFont(screen.getFont().deriveFont(30f));

		CalcButton buttonClr = new CalcButton("clr", null, (e) -> model.clear(), null);
		CalcButton buttonOneOverX = new CalcButton("1/x", null, (e) -> {
			checkFrozenValue();
			model.setValue(1 / model.getValue());
		}, null);
		CalcButton buttonReset = new CalcButton("reset", null, (e) -> model.clearAll(), null);
		CalcButton buttonPush = new CalcButton("push", null, (e) -> {
			checkFrozenValue();
			stack.push(model.getValue());
		}, null);
		CalcButton buttonSwitch = new CalcButton("+/-", null, (e) -> {
			checkFrozenValue();
			model.swapSign();
		}, null);
		CalcButton buttonDecimalPoint = new CalcButton(".", null, (e) -> {
			checkFrozenValue();
			model.insertDecimalPoint();
		}, null);

		CalcButton buttonEquals = new CalcButton("=", null, (e) -> {
			if (model.isActiveOperandSet() && model.getPendingBinaryOperation() != null) {
				model.setValue(
						model.getPendingBinaryOperation().applyAsDouble(model.getActiveOperand(), model.getValue()));
				model.setPendingBinaryOperation(null);
			} else {
				model.setValue(model.getValue());
			}
		}, null);

		CalcButton buttonSin = new CalcButton("sin", "arcsin", 
				(e) -> {
					checkFrozenValue();
					model.setValue(Math.sin(model.getValue()));
				},
				(e) -> {
					checkFrozenValue();
					model.setValue(Math.asin(model.getValue()));
				});

		CalcButton buttonDiv = new CalcButton("/", null, 
				(e) -> {
					validateOperation();
					model.setPendingBinaryOperation((l, r) -> l / r);
				}, null);

		CalcButton buttonLog = new CalcButton("log", "10^x", 
				(e) -> {
					checkFrozenValue();
					model.setValue(Math.log10(model.getValue()));
				},
				(e) -> {
					checkFrozenValue();
					model.setValue(Math.pow(10, model.getValue()));
				});

		CalcButton buttonCos = new CalcButton("cos", "arccos", 
				(e) -> {
					checkFrozenValue();
					model.setValue(Math.cos(model.getValue()));
				},
				(e) -> {
					checkFrozenValue();
					model.setValue(Math.acos(model.getValue()));
				});

		CalcButton buttonMul = new CalcButton("*", null, 
				(e) -> {
					validateOperation();
					model.setPendingBinaryOperation((l, r) -> l * r);
				}, null);

		CalcButton buttonLn = new CalcButton("ln", "e^x", 
				(e) -> {
					checkFrozenValue();
					model.setValue(Math.log(model.getValue()));
				},
				(e) -> {
					checkFrozenValue();
					model.setValue(Math.exp(model.getValue()));
				});

		CalcButton buttonTan = new CalcButton("tan", "arctan", 
				(e) -> {
					checkFrozenValue();
					model.setValue(Math.tan(model.getValue()));
				},
				(e) -> {
					checkFrozenValue();
					model.setValue(Math.atan(model.getValue()));
				});

		CalcButton buttonMinus = new CalcButton("-", null, 
				(e) -> {
					validateOperation();
					model.setPendingBinaryOperation((l, r) -> l - r);
				}, null);

		CalcButton buttonPop = new CalcButton("pop", null,
				(e) -> {
					checkFrozenValue();
					if (stack.isEmpty()) {
						throw new EmptyStackException();
					}
					model.setValue(stack.pop());
				}, null);

		CalcButton buttonPow = new CalcButton("x^n", "x^(1/n)", 
				(e) -> {
					validateOperation();
					if (((CalcButton) e.getSource()).isInverted()) {
						model.setPendingBinaryOperation((l, r) -> Math.pow(l, 1 / r));
					} else {
						model.setPendingBinaryOperation((l, r) -> Math.pow(l, r));
					}
				}, null);

		CalcButton buttonCtg = new CalcButton("ctg", "arcctg", 
				(e) -> {
					checkFrozenValue();
					model.setValue(1 / Math.tan(model.getValue()));
				},
				(e) -> {
					checkFrozenValue();
					model.setValue(Math.atan(1 / model.getValue()));
				});

		CalcButton buttonPlus = new CalcButton("+", null, 
				(e) -> {
					validateOperation();
					model.setPendingBinaryOperation((l, r) -> l + r);
				}, null);

		JCheckBox checkboxInv = new JCheckBox("Inv");
		checkboxInv.addActionListener(e -> invert());
		
		CalcButton button0 = new CalcButton("0", null, (e) -> model.insertDigit(0), null);
		button0.setFont(button0.getFont().deriveFont(30f));
		CalcButton button1 = new CalcButton("1", null, (e) -> model.insertDigit(1), null);
		button1.setFont(button1.getFont().deriveFont(30f));
		CalcButton button2 = new CalcButton("2", null, (e) -> model.insertDigit(2), null);
		button2.setFont(button2.getFont().deriveFont(30f));
		CalcButton button3 = new CalcButton("3", null, (e) -> model.insertDigit(3), null);
		button3.setFont(button3.getFont().deriveFont(30f));
		CalcButton button4 = new CalcButton("4", null, (e) -> model.insertDigit(4), null);
		button4.setFont(button4.getFont().deriveFont(30f));
		CalcButton button5 = new CalcButton("5", null, (e) -> model.insertDigit(5), null);
		button5.setFont(button5.getFont().deriveFont(30f));
		CalcButton button6 = new CalcButton("6", null, (e) -> model.insertDigit(6), null);
		button6.setFont(button6.getFont().deriveFont(30f));
		CalcButton button7 = new CalcButton("7", null, (e) -> model.insertDigit(7), null);
		button7.setFont(button7.getFont().deriveFont(30f));
		CalcButton button8 = new CalcButton("8", null, (e) -> model.insertDigit(8), null);
		button8.setFont(button8.getFont().deriveFont(30f));
		CalcButton button9 = new CalcButton("9", null, (e) -> model.insertDigit(9), null);
		button9.setFont(button9.getFont().deriveFont(30f));
		
		invertibleOperations.add(buttonCtg);
		invertibleOperations.add(buttonPow);
		invertibleOperations.add(buttonSin);
		invertibleOperations.add(buttonLog);
		invertibleOperations.add(buttonCos);
		invertibleOperations.add(buttonLn);
		invertibleOperations.add(buttonTan);
		
		cp.add(screen, "1,1");
		cp.add(button0, "5,3");
		cp.add(button1, "4,3");
		cp.add(button2, "4,4");
		cp.add(button3, "4,5");
		cp.add(button4, "3,3");
		cp.add(button5, "3,4");
		cp.add(button6, "3,5");
		cp.add(button7, "2,3");
		cp.add(button8, "2,4");
		cp.add(button9, "2,5");
		cp.add(buttonEquals, "1,6");
		cp.add(buttonClr, "1,7");
		cp.add(buttonOneOverX, "2,1");
		cp.add(buttonSin, "2,2");
		cp.add(buttonDiv, "2,6");
		cp.add(buttonReset, "2,7");
		cp.add(buttonLog, "3,1");
		cp.add(buttonCos, "3,2");
		cp.add(buttonMul, "3,6");
		cp.add(buttonPush, "3,7");
		cp.add(buttonLn, "4,1");
		cp.add(buttonTan, "4,2");
		cp.add(buttonMinus, "4,6");
		cp.add(buttonPop, "4,7");
		cp.add(buttonPow, "5,1");
		cp.add(buttonCtg, "5,2");
		cp.add(buttonSwitch, "5,4");
		cp.add(buttonDecimalPoint, "5,5");
		cp.add(buttonPlus, "5,6");
		cp.add(checkboxInv, "5,7");
	}

	/**
	 * Metoda koja invertira sve potrebne gumbe na kalkulatoru.
	 */
	private void invert() {
		for (CalcButton b : invertibleOperations) {
			b.invert();
		}
	}

	/**
	 * Metoda priprema kalkulator za izvođenje binarne operacije, tj. najprije provodi zakazanu operaciju (ako ona postoji),
	 * a zatim postavlja aktivni operand.
	 */
	private void validateOperation() {
		checkFrozenValue();
		if (model.getPendingBinaryOperation() == null) {
			model.setActiveOperand(model.getValue());
		} else if (model.isActiveOperandSet()) {
			model.setValue(model.getPendingBinaryOperation().applyAsDouble(model.getActiveOperand(), model.getValue()));
			model.setActiveOperand(model.getValue());
			model.setPendingBinaryOperation(null);
		}
		model.freezeValue();
	}
	
	private void checkFrozenValue() {
		if (model.hasFrozenValue())
			throw new CalculatorInputException("Illegal operation: Calculator has a frozen value!");
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			Calculator calc = new Calculator();
			calc.setVisible(true);
		});
	}

}