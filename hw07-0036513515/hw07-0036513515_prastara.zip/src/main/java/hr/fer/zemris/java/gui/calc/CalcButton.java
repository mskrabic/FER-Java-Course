package hr.fer.zemris.java.gui.calc;

import java.awt.event.ActionListener;

import javax.swing.JButton;

/**
 * Razred predstavlja implementaciju gumba na kalkulatoru {@link Calculator}.
 * 
 * @author mskrabic
 */
public class CalcButton extends JButton {
	
	/**
	 * Zastavica koja određuje treba li gumb provesti operaciju ili njen inverz.
	 */
	private boolean inverted;
	
	/**
	 * Tekst koji se prikazuje na gumbu kada zastavica <code>inverted</code> NIJE postavljena.
	 */
	private String text;
	/**
	 * Tekst koji se prikazuje na gumbu kada je zastavica <code>inverted</code> postavljena.
	 */
	private String invText;
	
	/**
	 * Operacija koju gumb provodi.
	 */
	private ActionListener operation;
	
	/**
	 * Inverz operacije koju gumb provodi.
	 */
	private ActionListener invOperation;

	/**
	 * Serijski broj.
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Konstruktor koji inicijalizira sve vrijednosti gumba.
	 * @param text tekst koji se želi prikazati na gumbu
	 * @param invText tekst koji se želi prikazati na gumbu kada je zastavica <code>inverted</code> postavljena.
	 * @param operation operacija koju gumb treba provoditi.
	 * @param invOperation inverz operacije koju gumb treba provoditi.
	 */
	public CalcButton(String text, String invText, ActionListener operation, ActionListener invOperation) {
		this.text = text;
		this.invText = invText == null ? text : invText;
		this.setText(text);
		this.inverted = false;
		this.operation = operation;
		this.invOperation = (invOperation == null) ? operation : invOperation;
		addActionListener(operation);
	}
	
	/**
	 * Metoda invertira gumb, tj. mijenja tekst koji se prikazuje na gumbu i operaciju koju on provodi kada se klikne.
	 */
	public void invert() {
		this.inverted = !this.inverted;
		this.setText(inverted ? invText : text);
		
		if (this.inverted) {
			removeActionListener(operation);
			addActionListener(invOperation);
		} else {
			removeActionListener(invOperation);
			addActionListener(operation);
		}
	
	}
	
	/**
	 * Metoda provjerava je li gumb invertiran.
	 * 
	 * @return <code>true</code> ako je, <code>false</code> inače.
	 */
	public boolean isInverted() {
		return inverted;
	}

}
